import io
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile
from PIL import Image

ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}
MAX_SIZE = (256, 256)


# ============================================================
# --> Image Preprocessing Helpers <--
# ============================================================


def center_crop_square(image: Image.Image) -> Image.Image:
    """
    Crops the image to a centered square by trimming the longer dimension.
    Simple and predictable: no background-color guessing, so it can never
    produce a mismatched-color bar around the subject — worst case it crops
    a bit off the sides/top/bottom, never adds anything.
    """
    width, height = image.size
    side = min(width, height)
    left = (width - side) // 2
    top = (height - side) // 2
    return image.crop((left, top, left + side, top + side))


# ============================================================
# --> Image Upload & Storage <--
# ============================================================


def save_image(
    file: UploadFile,
    folder: str,
    filename_prefix: str,
    entity_id: int,
    resize: tuple[int, int] = MAX_SIZE,
) -> str:
    """
    Saves an uploaded image after validation and processing.

    Args:
        file: Uploaded image.
        folder: Folder inside the media directory.
        filename_prefix: Prefix for the filename (e.g. "product", "user").
        entity_id: ID of the entity the image belongs to.
        resize: Final image size.

    Returns:
        Relative path to the saved image.
    """
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Only JPEG, PNG, and WEBP images are allowed.",
        )

    media_dir = Path("media") / folder
    media_dir.mkdir(parents=True, exist_ok=True)

    raw_bytes = file.file.read()

    # --> Step 1: validate that the uploaded file is a real image <--
    try:
        image = Image.open(io.BytesIO(raw_bytes))
        image.verify()
    except Exception:
        raise HTTPException(
            status_code=400,
            detail="The uploaded file is corrupted or is not a valid image.",
        )

    # --> Image.verify() invalidates the object for further use — reopen it <--
    image = Image.open(io.BytesIO(raw_bytes))

    # --> Step 2: JPEG doesn't support transparency, convert if needed.
    #     (No redundant re-open afterwards — that was the bug in the original,
    #     it discarded this conversion by reopening raw bytes right after.) <--
    if image.mode in ("RGBA", "LA", "P") and file.content_type == "image/jpeg":
        image = image.convert("RGB")

    # --> Step 3: crop to a centered square. Simple and predictable — no
    #     background-color guessing, so it never adds artificial colored bars.
    #     If you upload a photo that isn't already roughly square, this will
    #     crop off the sides (landscape) or top/bottom (portrait). <--
    image = center_crop_square(image)

    # --> Step 4: resize to the final size (don't upscale if already smaller) <--
    if image.width > resize[0]:
        image = image.resize(resize, Image.LANCZOS)
    else:
        image.thumbnail(resize, Image.LANCZOS)

    # --> Step 5: determine the file extension and save format <--
    extension_map = {
        "image/jpeg": ("jpg", "JPEG"),
        "image/png": ("png", "PNG"),
        "image/webp": ("webp", "WEBP"),
    }
    extension, image_format = extension_map[file.content_type]

    filename = f"{filename_prefix}_{entity_id}-{uuid.uuid4().hex}.{extension}"
    filepath = media_dir / filename

    save_kwargs = {"quality": 85} if image_format in ("JPEG", "WEBP") else {}
    image.save(filepath, format=image_format, **save_kwargs)

    return f"/media/{folder}/{filename}"


def delete_image(image_url: str | None) -> None:
    """Deletes the old file from disk, if one existed."""
    if not image_url:
        return
    old_path = Path("media") / image_url.removeprefix("/media/")
    old_path.unlink(missing_ok=True)